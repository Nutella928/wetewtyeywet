package com.tarzakiwi.followers;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;
import java.util.*;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.*;

public class TarzaKiwiFollowersClient implements ClientModInitializer {
    public static final List<Follower> FOLLOWERS = new ArrayList<>();
    private static KeyMapping key;

    public void onInitializeClient() {
        key = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.tarzakiwi_followers.open", GLFW.GLFW_KEY_P, KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (key.consumeClick()) client.setScreen(new FollowerScreen());
            if (client.player != null) FOLLOWERS.forEach(f -> f.tick(client));
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) ->
            dispatcher.register(literal("clientitem")
                .executes(c -> add("minecraft:sculk", "Скалк"))
                .then(argument("id", StringArgumentType.word())
                    .executes(c -> {
                        String id=StringArgumentType.getString(c,"id");
                        return add(id,id);
                    })
                    .then(argument("name", StringArgumentType.greedyString())
                        .executes(c -> add(StringArgumentType.getString(c,"id"),
                                            StringArgumentType.getString(c,"name")))))));
    }

    static int add(String id, String name) {
        Item item = null;
        try { item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(id)); } catch (Exception ignored) {}
        if (item == null) item = BuiltInRegistries.ITEM.get(ResourceLocation.parse("minecraft:sculk"));
        FOLLOWERS.add(new Follower(UUID.randomUUID(), new ItemStack(item), name));
        return 1;
    }

    public static class Follower {
        final UUID id; final ItemStack stack; String name; float size=1f;
        double x,y,z;
        Follower(UUID id, ItemStack stack, String name){this.id=id;this.stack=stack;this.name=name;}
        void tick(Minecraft mc) {
            double t=mc.player.tickCount*.07+(id.getLeastSignificantBits()&255);
            x=mc.player.getX()+Math.cos(t)*1.5;
            z=mc.player.getZ()+Math.sin(t)*1.5;
            y=mc.player.getY()+1.2+Math.sin(t*1.7)*.2;
        }
    }

    static class FollowerScreen extends Screen {
        FollowerScreen(){super(Component.literal("TarzaKiwiFollowers"));}
        protected void init() {
            int y=50;
            for(int i=0;i<FOLLOWERS.size();i++){
                final int n=i;
                addRenderableWidget(Button.builder(
                    Component.literal("Удалить: "+FOLLOWERS.get(i).name),
                    b->{FOLLOWERS.remove(n); rebuildWidgets();})
                    .bounds(20,y,260,20).build());
                y+=25;
            }
        }
        public void render(GuiGraphics g,int mx,int my,float d){
            renderBackground(g,mx,my,d);
            g.drawString(font,"TarzaKiwiFollowers",20,20,0xFFFFFF);
            g.drawString(font,"Клиентских спутников: "+FOLLOWERS.size(),20,35,0xAAAAAA);
            super.render(g,mx,my,d);
        }
    }
}